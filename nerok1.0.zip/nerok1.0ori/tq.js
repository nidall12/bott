//author : nerokskibidi yt : 4 K I R A CH
base : kirzbot
thanks to : lorengzo (mastah), didid (mastah), rezzx (my partner)