require("./module")
require("./color")
require("./settings")
require("./spinner")
require("./upload")
require("./mess")
require("./exif")
require("./button")
require("./canvas")

global.API = (name, path = "/", query = {}, apikeyqueryname) =>
	(name in global.APIs ? global.APIs[name] : name) +
	path +
	(query || apikeyqueryname
	  ? "?" +
		new URLSearchParams(
		  Object.entries({
			...query,
			...(apikeyqueryname
			  ? {
				  [apikeyqueryname]:
					global.APIKeys[
					  name in global.APIs ? global.APIs[name] : name
					],
				}
			  : {}),
		  }),
	    )
      : "");
			
  

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})