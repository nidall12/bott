const axios = require("axios");
const cheerio = require("cheerio");

const clean = (data) => {
  let regex = /(<([^>]+)>)/gi;
  data = data.replace(/(<br?\s?\/>)/gi, " \n");
  return data.replace(regex, "");
};

async function shortener(url) {
  return url;
}

exports.Tiktok = async(query) => {
  try {
    let response = await axios("https://lovetik.com/api/ajax/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
        "Referer": "https://lovetik.com",
        "Origin": "https://lovetik.com",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
      },
      data: new URLSearchParams(Object.entries({ query })),
    });
    

    result = {};

    result.creator = "YNTKTS";
    result.title = clean(response.data.desc || "");
    result.author = clean(response.data.author || "");
    result.nowm = await shortener(
      (response.data.links[0].a || "").replace("https", "http")
    );
    result.watermark = await shortener(
      (response.data.links[1].a || "").replace("https", "http")
    );
    result.audio = await shortener(
      (response.data.links[2].a || "").replace("https", "http")
    );
    result.thumbnail = await shortener(response.data.cover || "");
    
    return result;

  } catch (error) {
    console.error("Error fetching TikTok data:", error.message);
    throw error;
  }
};
