require("./module")
const fs = require('fs')
const chalk = require('chalk')

//setting bot
global.owner = "6283879792151"
global.namabot = "4 K I R A"
global.namaCreator = "4 K I R A"
global.foother = "Created By 4 K I R A"
global.autoJoin = false 
global.antilink = false 
global.versisc = '1.0'
//setting menu
global.imageurl = 'https://telegra.ph/file/c97209c2090564ab39c7d.jpg'
global.isLink = 'https://whatsapp.com/channel/0029VajuK8QCxoB00vq2d42F'
global.thumb = fs.readFileSync("./nerokskibidi.jpg")
global.audionya = fs.readFileSync("./all/sound.mp3")
global.author = "Nerox <!>"
global.simbol = '⛨'
global.packname = "© 4 K I R A <!>"
global.author = "Nerox <!>"
global.wm = 'Powered By 4 K I R A'
global.namastore = "NeroxOffc"
global.chsaluran = "https://whatsapp.com/channel/0029VajuK8QCxoB00vq2d42F"

//setting delay
global.delayjpm = 5000 //delay jpm
global.delaypushkontak = 7000 //delay pushkontak

//setting vps
global.apido = "-" //isi apikey digital ocean buat cvps
//kalo gk ada kosongin aja

//globaltoken
global.tokeninstall = "neroxsikma"
global.bash = "bash <(curl https://raw.githubusercontent.com/neroxkira/nerox0817/main/install.sh)"
global.bash1 = "bash <(curl https://raw.githubusercontent.com/neroxkira/nerox0817/main/install.sh)"
global.tokeninstall1 = "neroxsikma"
global.bash2 = "bash <(curl https://raw.githubusercontent.com/neroxkira/nerox0817/main/install.sh)"
global.tokeninstall2 = "neroxsikma"

//==================================
global.mupar = 'OnLasdan'
global.org = '4SVXAlaZC9Ix9LK5O33M7qeZ'
global.openai = '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'
global.APIs = {
can: 'https://pnggilajacn.my.id',
xteam: 'https://api.xteam.xyz', 
nrtm: 'https://fg-nrtm.ddns.net',
bg: 'http://bochil.ddns.net',
lol : 'https://api.lolhuman.xyz' , 
fgmods: 'https://api-fgmods.ddns.net',
violetics : 'https://violetics.pw',
zenz: 'https://zenzapi.xyz',
xzn: 'https://skizo.tech',
ibeng: 'https://api.ibeng.tech', 

}

global.APIKeys = {
'https://pnggilajacn.my.id': 'ItsukaChan',
'https://api.xteam.xyz': 'd90a9e986e18778b',
'https://zenzapis.xyz': '675e34de8a', 
'https://api-fgmods.ddns.net': 'Pa5SYPbA',
'https://zenzapi.xyz': '01ABEB1E11',
'https://violetics.pw': 'beta',
'https://api.lolhuman.xyz': 'haikalgans',
'https://skizo.tech': 'konekocyz', 
'https://api.ibeng.tech' : 'QeyZTULyQg', 
}

//setting panel #1
global.domain = '-'
global.apikey = '-'
global.capikey = '-'
global.eggsnya = '15' 
global.location = '1'

//============================

//setting panel private
global.domain2 = '-'
global.apikey2 = '-'
global.capikey2 = '-'
global.eggsnya = '15' 
global.location = '1'

//============================


//setting nomor
global.dana = '-'
global.ovo = '-'
global.gopay = '-'
global.qris = '-'
//Kalo gk ada ubah jadi false

//============================